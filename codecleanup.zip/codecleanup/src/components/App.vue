<template>
  <div id="app">
    <app-nav></app-nav>
    <div class="container-fluid app-content">
      <breadcrumbs/>
      <router-view></router-view>
    </div>
  </div>

</template>

<script>
import AppNav from './AppNav.vue'
export default {
  name: 'app',
  components: { AppNav },
  data () {
    return {
    }
  }
}
</script>

<style lang="scss">

</style>
