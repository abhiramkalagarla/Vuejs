<template>
  <b-row>
  <b-col class="mt-10" md="12">
   <h2>Application Info</h2>
   <div>
    <b-form inline @submit="onSubmit">
      <label class="sr-only" for="formcsid">csiID</label>
      <b-input class="mb-4 mr-sm-2 mb-sm-0" id="formcsid"
      @input="$v.form.csiID.$touch()"
                    v-model="form.csiID"
                    :state="!$v.form.csiID.$invalid"
       placeholder="Enter csiID" />
      <b-button type="submit" variant="primary" :disabled="$v.form.$invalid">Get Application Info</b-button>
    </b-form>
  </div>
</b-col>
<b-col md="12" v-if="appInfo!=''">
{{appInfo}}
</b-col>
  </b-row>
</template>

<script>
import { validationMixin } from 'vuelidate'
import { required } from 'vuelidate/lib/validators'
export default {
  name: 'ApplicationInfo',
  data () {
    return {
      auth: this.$store.state.auth,
      form: {},
      appInfo: ''
    }
  },
  mixins: [validationMixin],
  validations: {
    form: {
      csiID: {
        required
      }
    }
  },
  methods: {
    onSubmit (e) {
      e.preventDefault()
      this.getappInfo()
    },
    getappInfo () {
      const apiheaders = {
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json'
  }
}
      const infoProps = {
        'action': 'com.citi.cloud.oms/getAppInfo',
        'parameters': {
          'csiID': this.form.csiID
          }
          }
          
      this.$http
        .get('/api/apps?CSIID=' + this.form.csiID, apiheaders)
        .then((response) => {
          this.appInfo = response;
        })
        .catch((response) => {
          console.log(response)
          // this.error = utils.getError(response)
        })
    }
  }
  
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
