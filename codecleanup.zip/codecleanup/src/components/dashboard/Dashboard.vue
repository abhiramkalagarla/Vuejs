<template>
  <div><b-row>
  <b-col class="mt-10">
    <b-card-group deck>
        <b-card title="Database Protection Services(Actifio)">
            <p class="card-text">
                Database protection services provides automated backup and restore of Databases for physical servers with Actifio
            </p>
            <div slot="footer">
                <b-button to="actifio"
                      variant="primary">Order</b-button>
            </div>
        </b-card>

        <b-card title="Scale IO">
            <p class="card-text">
                All Resources (also called catalog items) available in the OMS are ordered on behalf of a Citi Application (app)
            </p>
            <div slot="footer">
                <b-button to="scaleIO" disabled
                      variant="primary">Order</b-button>
            </div>
        </b-card>

        <b-card title="VM Replication">
            <p class="card-text">
                Some orders will require user to provide server names
            </p>
            <div slot="footer">
                <b-button to="vmReplication" disabled
                      variant="primary">Order</b-button>
            </div>
        </b-card>
        
        <b-card title="ObjectStorage">
            <p class="card-text">
                List of all My past orders with status
            </p>
            <div slot="footer">
                <b-button to="objectStorage" disabled
                      variant="primary">Order</b-button>
            </div>
        </b-card>
    </b-card-group>
 </b-col>
 </b-row>
 </div>
</template>

<script>
export default {
  name: 'Dashboard',
  data () {
    return {
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.mt-10{
  margin-top:10px;
}
</style>
