<template>
  <div>
 <h3>{{$route.params.citipoolname}} - Details 
 <b-button-group size="sm">
    <b-button @click="enableAction('PT')">Edit Pool Type</b-button>
    <b-button @click="enableAction('PC')">Edit Pool Capacity</b-button>
    <b-button @click="enableAction('ED')">Enable / Disable</b-button>
  </b-button-group></h3>
 
 <b-form >
  
    <b-form-group id="OfflinePools"
                  label="Data Center"
                  horizontal
                :label-cols="4"
                breakpoint="md"
                  label-for="datacenter">
      <b-form-input id="datacenter"
                    type="text"
                    disabled
                    v-model="poolDetails.dataCenter"
                    aria-describedby="datacenter"
                    placeholder="DataCenter" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="Pool ID"
                  horizontal
                :label-cols="4"
                breakpoint="md"
                  label-for="id">
      <b-form-input id="id"
                    type="text"
                    disabled
                    v-model="poolDetails.id"
                    aria-describedby="id"
                    placeholder="Pool ID" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="Citi Pool Name"
                  horizontal
                :label-cols="4"
                breakpoint="md"
                  label-for="citipoolname">
      <b-form-input id="citipoolname"
                    type="text"
                    disabled
                    v-model="poolDetails.citiPoolName"
                    aria-describedby="citipoolname"
                    placeholder="Citi Pool Name" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="Pool Name"
                  horizontal
                :label-cols="4"
                breakpoint="md"
                  label-for="poolname">
      <b-form-input id="poolname"
                    type="text"
                    disabled
                    v-model="poolDetails.poolName"
                    aria-describedby="poolname"
                    placeholder="Pool Name" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="antut"
                  horizontal
                :label-cols="4"
                breakpoint="md"
                  label-for="antut">
      <b-form-input id="antut"
                    type="text"
                    disabled
                    v-model="poolDetails.antut"
                    aria-describedby="antut"
                    placeholder="antut" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="Pool Status"
                  horizontal
                :label-cols="4"
                breakpoint="md"
                  label-for="poolstatus">
      <b-form-input id="poolstatus"
                    type="text"
                    disabled
                    v-model="poolDetails.poolStatus"
                    aria-describedby="poolstatus"
                    placeholder="PoolStatus" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="maxoc"
                  horizontal
                :label-cols="4"
                breakpoint="md"
                  label-for="maxoc">
      <b-form-input id="maxoc"
                    type="text"
                    disabled
                    v-model="poolDetails.maxoc"
                    aria-describedby="maxoc"
                    placeholder="maxoc" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="ClusterType"
                  horizontal
                :label-cols="4"
                breakpoint="md"
                  label-for="sioClusterType">
      <b-form-input id="sioClusterType"
                    type="text"
                    disabled
                    v-model="poolDetails.sioClusterType"
                    aria-describedby="sioClusterType"
                    placeholder="ClusterType" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="maxut"
                  horizontal
                :label-cols="4"
                breakpoint="md"
                  label-for="maxut">
      <b-form-input id="maxut"
                    type="text"
                    disabled
                    v-model="poolDetails.maxut"
                    aria-describedby="maxut"
                    placeholder="maxut" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="PoolTier"
                  horizontal
                :label-cols="4"
                breakpoint="md"
                  label-for="poolTier">
      <b-form-input id="poolTier"
                    type="text"
                    disabled
                    v-model="poolDetails.poolTier"
                    aria-describedby="poolTier"
                    placeholder="PoolTier" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="Newage"
                  horizontal
                :label-cols="4"
                breakpoint="md"
                  label-for="newage">
      <b-form-input id="newage"
                    type="text"
                    disabled
                    v-model="poolDetails.newage"
                    aria-describedby="newage"
                    placeholder="newage" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="sioSPId"
                  horizontal
                :label-cols="4"
                breakpoint="md"
                  label-for="sioSPId">
      <b-form-input id="sioSPId"
                    type="text"
                    disabled
                    v-model="poolDetails.sioSPId"
                    aria-describedby="sioSPId"
                    placeholder="sioSPId" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="PoolType"
                  horizontal
                :label-cols="4"
                breakpoint="md"
                  label-for="poolType">
      <b-form-input id="poolType"
                    type="text"
                    disabled
                    v-model="poolDetails.poolType"
                    aria-describedby="poolType"
                    placeholder="PoolType" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="sioClusterName"
                  horizontal
                :label-cols="4"
                breakpoint="md"
                  label-for="sioClusterName">
      <b-form-input id="poolname"
                    type="text"
                    disabled
                    v-model="poolDetails.sioClusterName"
                    aria-describedby="sioClusterName"
                    placeholder="sioClusterName" />
    </b-form-group>

    <b-form-group id="OfflinePools"
                  label="sioPDId"
                  horizontal
                :label-cols="4"
                breakpoint="md"
                  label-for="sioPDId">
      <b-form-input id="sioPDId"
                    type="text"
                    disabled
                    v-model="poolDetails.sioPDId"
                    aria-describedby="sioPDId"
                    placeholder="sioPDId" />
    </b-form-group>

 </b-form>

 <div v-if="showtype">
 <h5>Update Pool Type</h5>
 <b-form >

    <b-form-group id="OfflinePools"
                  label="PoolType"
                  horizontal
                  :label-cols="4"
                breakpoint="md"
                  label-for="poolType">
                  <b-form-select id="poolType"
                    :options="type"
                     v-model="poolDetails.poolType" />
    </b-form-group>

 </b-form>
 </div>
 <div v-if="showCapacity">
 <h5>Update Pool Capacity</h5>
 <b-form >
  
    <b-form-group id="OfflinePools"
                  label="antut"
                  horizontal
                :label-cols="4"
                breakpoint="md"
                  label-for="antut">
      <b-form-input id="antut"
                    type="text"
                    disabled
                    v-model="poolDetails.antut"
                    aria-describedby="antut"
                    placeholder="antut" />
    </b-form-group>
    
    <b-form-group id="OfflinePools"
                  label="maxoc"
                  horizontal
                :label-cols="4"
                breakpoint="md"
                  label-for="maxoc">
      <b-form-input id="maxoc"
                    type="text"
                    disabled
                    v-model="poolDetails.maxoc"
                    aria-describedby="maxoc"
                    placeholder="maxoc" />
    </b-form-group>
    
    <b-form-group id="OfflinePools"
                  label="maxut"
                  horizontal
                :label-cols="4"
                breakpoint="md"
                  label-for="maxut">
      <b-form-input id="maxut"
                    type="text"
                    disabled
                    v-model="poolDetails.maxut"
                    aria-describedby="maxut"
                    placeholder="maxut" />
    </b-form-group>
    
    <b-form-group id="OfflinePools"
                  label="Newage"
                  horizontal
                :label-cols="4"
                breakpoint="md"
                  label-for="newage">
      <b-form-input id="newage"
                    type="text"
                    disabled
                    v-model="poolDetails.newage"
                    aria-describedby="newage"
                    placeholder="newage" />
    </b-form-group>

 </b-form>
 </div>
 <div v-if="showEnable">
 <h5>Enavle / Diable Pool</h5>
 </div>
  </div>
</template>

<script>
import { validationMixin } from 'vuelidate'
import { required } from 'vuelidate/lib/validators'
const apiheaders = {
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          'x-ibm-client-id': '53b6ce72-6157-4bdb-b1ce-afdcfd1adce5',
          'x-ibm-client-secret': 'gV0bI3iU6uV1sN1lX2sD2iB8bC4dG4rT5rC3eF3kW3dC6nD0jY'
  }
}
export default {
  name: 'indpools',
  data () {
    return {
    type: ['thin', 'thick'],
    poolDetails: [],
    showDetails: true,
    showtype: false,
    showCapacity: false,
    showEnable: false
    }
  },
  mixins: [validationMixin],
  validations: {
    poolDetails: {
      poolType: {
        required: this.showtype
      },
      antut: {
        required: this.showCapacity
      },
      maxoc: {
        required: this.showCapacity
      },
      maxut: {
        required: this.showCapacity
      },
      newage: {
        required: this.showCapacity
      },
      poolStatus: {
        required: this.showEnable
      }
      
    }
  },
  created () {
     this.getpoolDetails();
  },
  methods: {
      enableAction (actionType) {
switch (actionType) {
    case 'PT' :
    this.showDetails = false; this.showtype = true; this.showCapacity = false; this.showEnable = false
    break;
    case 'PC' :
    this.showDetails = false; this.showtype = false; this.showCapacity = true; this.showEnable = false
    break;
    case 'ED' :
    this.showDetails = false; this.showtype = false; this.showCapacity = false; this.showEnable = true
    break;
    case 'SD' :
    this.showDetails = true; this.showtype = false; this.showCapacity = false; this.showEnable = false
    break;
}
      },
    getpoolDetails () {
      const infoProps = {
        'workflowSync': 'getSIOPool',
        'parameters': {
        'citiPoolName': this.$route.params.citipoolname
}

          }
          
      this.$http
        .post('https://vm-86ae-9639.nam.nsroot.net:6400/citistorage/sit/scaleio/management/execute?', infoProps, apiheaders)
        .then((response) => {
          this.poolDetails = response.body[0];
        })
        .catch((response) => {
          console.log(response)
        })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.mt-10{
  margin-top:10px;
}
</style>
