<template>
  <div>
  <button @click="newpool()" class="btn btn-success" >Add pool</button>

    <v-client-table :data="tableData" :columns="columns" :options="options">
        <template slot="actions" slot-scope="props">
          <div class="btn-group btn-group-sm">
            <b-link :to="{name:'Citipool',params:{citipoolname:props.row.citiPoolName}}" class="btn btn-primary">view Details</b-link>
            <button @click="deletepool(props.row)" class="btn btn-danger" >Delete</button>
          </div>
        </template>
        <template slot="status" slot-scope="props">
          <div class="switch">
            <input v-bind:id="props.row.id" class="cmn-toggle cmn-toggle-round-flat" v-on:change=togglepool($event,props.row) 
            v-bind:checked="props.row.status=='offline'?false:true" 
            v-bind:disabled="props.row.status=='offline'?false:true"
            type="checkbox">
            <label v-bind:for="props.row.id"></label>
          </div>
        </template>
    </v-client-table>

  <b-modal v-model="showModal" no-enforce-focus :hide-footer="hidefooter"  ref="myModalRef" :title="popupTitle"  @hidden="onHidden">
      <form @submit.stop.prevent="handleSubmit">
          <b-form-group id="DataCenter"
                      label="Data Center"
                      class="required"
                      label-for="datacenterInput">
          <b-form-input id="datacenterInput"
                      type="text"
                      v-model="currentItem.dataCenter"
                      :state="null"
                      aria-describedby="datacenterInputt"
                      placeholder="Enter Data Center" />
          <b-form-invalid-feedback id="datacenterInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="CitiPoolName"
                      label="Cluster"
                      class="required"
                      label-for="ClusterInput">
          <b-form-input id="ClusterInput"
                      type="text"
                      v-model="currentItem.cluster"
                      :state="null"
                      aria-describedby="ClusterInput"
                      placeholder="Enter Cluster" />
          <b-form-invalid-feedback id="Cluster">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="CitiPoolName"
                      label="Pool Name"
                      class="required"
                      label-for="poolnameInput">
          <b-form-input id="poolnameInput"
                      type="text"
                      v-model="currentItem.poolName"
                      :state="null"
                      aria-describedby="poolnameInput"
                      placeholder="Enter Pool Name" />
          <b-form-invalid-feedback id="poolnameInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="PoolTier"
                    label="Pool Tier"
                    class="required"
                    label-for="pooltierInput">
          <b-form-input id="pooltierInput"
                    type="text"
                    v-model="currentItem.poolTier"
                    :state="null"
                    aria-describedby="pooltierInput"
                    placeholder="Enter Pool Tier" />
          <b-form-invalid-feedback id="pooltierInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-form-group id="PoolType"
                    label="Pool Type"
                    class="required"
                    label-for="pooltypeInput">
          <b-form-input id="pooltypeInput"
                      type="text"
                      v-model="currentItem.poolType"
                      :state="null"
                      aria-describedby="pooltypeInput"
                      placeholder="Enter Pool Type" />
          <b-form-invalid-feedback id="pooltypeInput">
            This is a required field
          </b-form-invalid-feedback>
          </b-form-group>

          <b-button type="submit" variant="primary" :disabled="$v.currentItem.$invalid">
              Submit
          </b-button>
          <b-button type="button" @click="hidemodal()" variant="default">
            Cancel
          </b-button>
      </form>
    </b-modal>

    <b-modal  no-enforce-focus   ref="myDeleteModalRef" :title="'Deletepool '+ currentItem.citiPoolName" >
    Are You Sure, Do You Want to Delete {{currentItem.citiPoolName}} ?
    </b-modal>
  </div>
</template>

<script>
import { validationMixin } from 'vuelidate'
import { required } from 'vuelidate/lib/validators'
const apiheaders = {
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          'x-ibm-client-id': '53b6ce72-6157-4bdb-b1ce-afdcfd1adce5',
          'x-ibm-client-secret': 'gV0bI3iU6uV1sN1lX2sD2iB8bC4dG4rT5rC3eF3kW3dC6nD0jY'
  }
}
export default {
  name: 'pools',
  data () {
    return {
      showModal: false,
      hidefooter: true,
      popupTitle: 'New Item',
      Deletepool: '',
      theme: 'bootstrap4',
      currentItem: {},
      template: 'default',
      columns: ['citiPoolName', 'cluster', 'poolName', 'status', 'actions'],
      tableData: [],
      options: {
            templates: {
            },
            headings: {
                citiPoolName: 'Citi Pool Name',
                poolName: 'Pool Name'
            },
            text: {
                filter: 'Search pools:',
                filterPlaceholder: 'pools...',
                limit: 'Entries per Page: '
            },
            perPage: 10,
            pagination: { chunk: 10, dropdown: false }
            // see the options API
        }
    }
  },
  mixins: [validationMixin],
  validations: {
    currentItem: {
      cluster: {
        required
      },
      poolName: {
        required
      },
      datacenter: {
        required
      },
      poolTier: {
        required
      },
      poolType: {
        required
      }
    }
  },
  created () {
     this.getAllClusters();
  },
  methods: {
    onHidden () {
      this.currentItem = {}
      this.popupTitle = 'New Pool'
      this.showModal = false
    },
    hidemodal () {
    this.$refs.myModalRef.hide()
    },
    togglepool (ev, data) {
        if (ev.target.checked) {
    this.startpool(data.citiPoolName)
        }
        
       //  console.log(data)
    },
    newpool () {
        this.showModal = true
        this.currentItem = {}
        this.popupTitle = 'New Pool' 
        this.$refs.myModalRef.show()
    },
      editpool (data) {     
        this.showModal = true
        this.currentItem = data
        this.popupTitle = 'Edit Pool ' + data.citiPoolName
        this.$refs.myModalRef.show()
      },
      deletepool (data) {
        this.currentItem = data
        this.$refs.myDeleteModalRef.show()
      },
      handleSubmit () {
        var cO = Object.assign({}, this.currentItem);
        const infoProps = {
            'workflowSync': 'addSIOPool',
            checkBypass: false,
            JSONPools: JSON.stringify(cO)
          }
          
      this.$http
        .post('https://vm-86ae-9639.nam.nsroot.net:6400/citistorage/sit/scaleio/management/execute?', infoProps, apiheaders)
        .then((response) => {
          this.tableData = response.body;
        })
        .catch((response) => {
          console.log(response)
        })
      },
      startpool (poolname) {
          const infoProps = {
        'workflowSync': 'enableSIOPool',
        'parameters': {
        'citiPoolName': poolname
}   
 }

          this.$http
        .post('https://vm-86ae-9639.nam.nsroot.net:6400/citistorage/sit/scaleio/management/execute?', infoProps, apiheaders)
        .then((response) => {
          this.tableData = response.body;
        })
        .catch((response) => {
          console.log(response)
        })
      },
    getAllClusters () {
      const infoProps = {
        'workflowSync': 'listSIOPools'
          }
          
      this.$http
        .post('https://vm-86ae-9639.nam.nsroot.net:6400/citistorage/sit/scaleio/management/execute?', infoProps, apiheaders)
        .then((response) => {
          this.tableData = response.body;
        })
        .catch((response) => {
          console.log(response)
        })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.mt-10{
  margin-top:10px;
}
</style>
