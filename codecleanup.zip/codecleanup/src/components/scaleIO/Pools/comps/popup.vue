<template>
<form @submit.stop.prevent="handleSubmit">
        <b-form-group id="CitiPoolName"
                  label="Citi Pool Name"
                  class="required"
                  label-for="citipoolnameInput">
      <b-form-input id="citipoolnameInput"
                    type="text"
                    v-model="form.citiPoolName"
                    :state="null"
                    aria-describedby="citipoolnameInput"
                    placeholder="Enter Citi Pool Name" />
      <b-form-invalid-feedback id="citipoolnameInput">
       This is a required field
      </b-form-invalid-feedback>
    </b-form-group>

    <b-form-group id="CitiPoolName"
                  label="Cluster"
                  class="required"
                  label-for="ClusterInput">
      <b-form-input id="ClusterInput"
                    type="text"
                    v-model="form.cluster"
                    :state="null"
                    aria-describedby="ClusterInput"
                    placeholder="Enter Cluster" />
      <b-form-invalid-feedback id="Cluster">
       This is a required field
      </b-form-invalid-feedback>
    </b-form-group>

    <b-form-group id="CitiPoolName"
                  label="Pool Name"
                  class="required"
                  label-for="poolnameInput">
      <b-form-input id="poolnameInput"
                    type="text"
                    v-model="form.poolName"
                    :state="null"
                    aria-describedby="poolnameInput"
                    placeholder="Enter Pool Name" />
      <b-form-invalid-feedback id="poolnameInput">
       This is a required field
      </b-form-invalid-feedback>
    </b-form-group>
<b-button type="submit"
              variant="primary"
              :disabled="form.$invalid">
      Submit
    </b-button>
    <b-button type="button"
              variant="default"
              >
      Cancel
    </b-button>
  </form>
</template>
<script>
import { validationMixin } from 'vuelidate'
import { required } from 'vuelidate/lib/validators'
  export default {
      name: 'popup',
      props: ['formdata'],
    data () {
      return {
          form: Object.assign({}, this.formdata)
      }
    },
    mixins: [validationMixin],
    methods: {
    clearName () {

    },
      handleOk (evt) {
      evt.preventDefault()
    },
    handleSubmit () {
      this.$parent.$options.methods.hide()
    }
    }
  }
</script>
