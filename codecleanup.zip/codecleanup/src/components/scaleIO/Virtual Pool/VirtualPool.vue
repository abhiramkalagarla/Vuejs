<template>
  <div class="mt-3">
    
    <v-client-table :data="tableData" :columns="columns" :options="options">
    <div slot="afterLimit" class="pull-right">
    <button @click="newpool()" class="btn btn-success" >Create</button> 
</div>
      <template slot="actions" slot-scope="props">
        <div class="btn-group btn-group-sm">
         <b-link :to="{name:'IndvirtualPool',params:{vpID:props.row.id}}" class="btn btn-primary">view Details</b-link>
        <button @click="deletpool(props.row)" class="btn btn-danger" >Delete</button>
        </div>
      </template>
    </v-client-table>

  <b-modal v-model="showModal" no-enforce-focus :hide-footer="hidefooter"  ref="myModalRef" :title="popupTitle"  @hidden="onHidden">
      <form @submit.stop.prevent="handleSubmit">

      <b-form-group id="VirtualPoolName"
                  label="Virtual Pool Name"
                  class="required"
                  label-for="virtualpoolnameInput">
      <b-form-input id="virtualpoolnameInput"
                    type="text"
                    v-model="currentItem.vpName"
                    :state="null"
                    aria-describedby="virtualpoolnameInputt"
                    placeholder="Enter Virtual Pool Name" />
      <b-form-invalid-feedback id="virtualpoolnameInput">
       This is a required field
      </b-form-invalid-feedback>
    </b-form-group>

    <b-form-group id="OnlinePools"
                  label="Online Pools"
                  class="required"
                  label-for="onlinepoolsInput">
                  
                  <b-form-select id="poolType"
                  :options="OPools"
                  multiple
                  text-field="citiPoolName"
                  value-field="id"
                  v-model="currentItem.onlinePools" />
      
      <b-form-invalid-feedback id="onlinepoolsInput">
       This is a required field
      </b-form-invalid-feedback>
    </b-form-group>
      <b-form-group id="PoolTier"
                  label="Pool Tier"
                  class="required"
                  label-for="pooltierInput">
      <b-form-input id="pooltierInput"
                    type="text"
                    v-model="currentItem.poolTier"
                    :state="null"
                    aria-describedby="vpTierInput"
                    placeholder="Enter Pool Tier" />
      <b-form-invalid-feedback id="pooltierInput">
       This is a required field
      </b-form-invalid-feedback>
    </b-form-group>

    <b-form-group id="OfflinePools"
                  label="Offline Pools"
                  label-for="offlinepoolsInput">
      <b-form-input id="offlinepoolsInput"
                    type="text"
                    v-model="currentItem.offlinePools"
                    :state="null"
                    aria-describedby="offlinepoolsInput"
                    placeholder="Enter Offline Pools" />
      <b-form-invalid-feedback id="offlinepoolsInput">
       This is a required field
      </b-form-invalid-feedback>
    </b-form-group>

<b-form-group id="OfflinePools"
                  label="Data Center"
                  class="required"
                  label-for="datacenterInput">
      <b-form-input id="datacenterInput"
                    type="text"
                    v-model="currentItem.dataCenter"
                    :state="null"
                    aria-describedby="datacenterInput"
                    placeholder="Enter Data Center" />
      <b-form-invalid-feedback id="datacenterInput">
       This is a required field
      </b-form-invalid-feedback>
    </b-form-group>
<b-button type="submit" variant="primary" :disabled="$v.currentItem.$invalid">
              Submit
          </b-button>
          <b-button type="button" @click="hidemodal()" variant="default">
            Cancel
          </b-button>
    </form>
  </b-modal>
  <b-modal  no-enforce-focus  :hide-footer="hidefooter"  ref="myDeleteModalRef" :title="'Deletepool '+ currentItem.vpName" >
    Are You Sure, Do You Want to Delete {{currentItem.vpName}} ?
<hr/>
    <b-button type="button" variant="primary" @click="delVPool()" >
              ok
          </b-button>
          <b-button type="button" @click="hidecancelmodal()" variant="default">
            Cancel
          </b-button>
  </b-modal>
  </div>
</template>

<script>
import { validationMixin } from 'vuelidate'
import { required } from 'vuelidate/lib/validators'
import popup from './comps/popup.vue'
const apiheaders = {
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          'x-ibm-client-id': '53b6ce72-6157-4bdb-b1ce-afdcfd1adce5',
          'x-ibm-client-secret': 'gV0bI3iU6uV1sN1lX2sD2iB8bC4dG4rT5rC3eF3kW3dC6nD0jY'
  }
}
export default {
  name: 'virtualpools',
  components: { popup },
  data () {
    return {
        showModal: false,
        hidefooter: true,
        popupTitle: 'New Item',
        theme: 'bootstrap4',
        currentItem: {},
        template: 'default',
        OPools: [],
        columns: ['id', 'vpName', 'actions'],
        tableData: [],
        DeletevirtualPool: '',
        options: {
            templates: {
        },
            headings: {
                id: 'Virtual Pool ID',
                vpName: 'Virtual Pool Name'
            },
            text: {
                filter: 'Search  Virtual pools:',
                filterPlaceholder: 'Virtual pools...',
                limit: 'Entries per Page: '

            },
            perPage: 10,
            pagination: { chunk: 10, dropdown: false }
            // see the options API
        }
    }
  },
  mixins: [validationMixin],
  validations: {
    currentItem: {
      vpName: {
        required
      },
      onlinePools: {
        required
      },
      poolTier: {
        required
      },
      dataCenter: {
        required
      }
    }
  },
  created () {
     this.getAllVirtualPools();
     this.getOnlinePools();
  },
  methods: {
    onHidden () {
      this.currentItem = {}
      this.popupTitle = 'New Pool'
      this.showModal = false
    },
    newpool () {
        this.showModal = true
        this.currentItem = {}
        this.popupTitle = 'New Pool' 
        this.$refs.myModalRef.show()
    },
    hidemodal () {
    this.$refs.myModalRef.hide()
    },
    hidecancelmodal () {
    this.$refs.myDeleteModalRef.hide()
    },
      editpool (data) {     
        this.showModal = true
        this.currentItem = data
        this.popupTitle = 'Edit Pool ' + data.citiPoolName
        this.$refs.myModalRef.show()
      },
      deletpool (data) {
        this.currentItem = data
        this.$refs.myDeleteModalRef.show()
      },
      delVPool () {
      const infoProps = {
            'workflowSync': 'deleteSIOVP',
            'parameters': {
              'vpId': this.currentItem.id
            }
          }
          
      this.$http
        .post('https://vm-86ae-9639.nam.nsroot.net:6400/citistorage/sit/scaleio/management/execute?', infoProps, apiheaders)
        .then((response) => {
          console.log(response)
          if (response.body.status === 'ok') {
            this.$refs.myDeleteModalRef.hide()
            this.getAllVirtualPools()
            alert('virtual Pool Deleted succesfully')
          }
        })
        .catch((response) => {
          console.log(response)
        })
      },
      getOnlinePools () {
        const infoProps = {
            'workflowSync': 'listSIOPools'
          }
          
      this.$http
        .post('https://vm-86ae-9639.nam.nsroot.net:6400/citistorage/sit/scaleio/management/execute?', infoProps, apiheaders)
        .then((response) => {
          this.OPools = response.body;
        })
        .catch((response) => {
          console.log(response)
        })
      },
      handleSubmit () {
        var cO = Object.assign({}, this.currentItem);
        cO.vpTier = cO.poolTier
        
        var poolname = this.OPools.filter(function (obj) { 
         return obj.id === cO.onlinePools
        })[0];
        
        cO.onlinePools = [cO.onlinePools, poolname.citiPoolName];
        const infoProps = {
            'workflowSync': 'addSIOVP',
            'parameters': {
              vpData: JSON.stringify([cO])
              }
          }
          
      this.$http
        .post('https://vm-86ae-9639.nam.nsroot.net:6400/citistorage/sit/scaleio/management/execute?', infoProps, apiheaders)
        .then((response) => {
          if (response.body[0].status === 'ok') {
            this.hidemodal()
            this.getAllVirtualPools()
            alert('virtual Pool created succesfully')
          }
        })
        .catch((response) => {
          console.log(response)
        })
      },
    getAllVirtualPools () {
      const infoProps = {
        'workflowSync': 'listSIOVPs'
          }
          
      this.$http
        .post('https://vm-86ae-9639.nam.nsroot.net:6400/citistorage/sit/scaleio/management/execute?', infoProps, apiheaders)
        .then((response) => {
          this.tableData = response.body;
        })
        .catch((response) => {
          console.log(response)
        })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.mt-10{
  margin-top:10px;
}
</style>
