<template>
  <div>
 <h3>{{$route.params.vpID}} - Details</h3>

 <div class="row">
 <div class="col-md-7">

 <b-form v-if="showDetails">
       <b-form-group id="OfflinePools"
                  label="Virtual Pool Data Center"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="dataCenter">
      <b-form-input id="dataCenter"
                    type="text"
                    disabled
                    v-model="virtualpoolDetails.dataCenter"
                    aria-describedby="dataCenter"
                    placeholder="Virtual Pool Data Center" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="Virtual Pool ID"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="id">
      <b-form-input id="id"
                    type="text"
                    disabled
                    v-model="virtualpoolDetails.id"
                    aria-describedby="id"
                    placeholder="VP ID" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="Offline Pools"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="offlinePools">
      <b-form-input id="offlinePools"
                    type="text"
                    disabled
                    v-model="virtualpoolDetails.offlinePools"
                    aria-describedby="offlinePools"
                    placeholder="Offline Pools" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="Online Pools"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="onlinePools">
      <b-form-input id="onlinePools"
                    type="text"
                    disabled
                    v-model="virtualpoolDetails.onlinePools"
                    aria-describedby="onlinePools"
                    placeholder="Online Pools" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="Virtual Pool Name"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="vpName">
      <b-form-input id="vpName"
                    type="text"
                    disabled
                    v-model="virtualpoolDetails.vpName"
                    aria-describedby="vpName"
                    placeholder="Virtual Pool Name" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="Virtual Pool Status"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="vpStatus">
      <b-form-input id="vpStatus"
                    type="text"
                    disabled
                    v-model="virtualpoolDetails.vpStatus"
                    aria-describedby="vpStatus"
                    placeholder="Virtual Pool Status" />
    </b-form-group>
    <b-form-group id="OfflinePools"
                  label="Virtual Pool Tier"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="vpTier">
      <b-form-input id="vpTier"
                    type="text"
                    disabled
                    v-model="virtualpoolDetails.vpTier"
                    aria-describedby="vpTier"
                    placeholder="Virtual Pool Tier" />
    </b-form-group>
 </b-form>
 </div>
 </div>
  </div>
</template>

<script>
import { validationMixin } from 'vuelidate'
import { required } from 'vuelidate/lib/validators'
const apiheaders = {
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          'x-ibm-client-id': '53b6ce72-6157-4bdb-b1ce-afdcfd1adce5',
          'x-ibm-client-secret': 'gV0bI3iU6uV1sN1lX2sD2iB8bC4dG4rT5rC3eF3kW3dC6nD0jY'
  }
}
export default {
  name: 'indvirtualpools',
  data () {
    return {
    virtualpoolDetails: [],
    showDetails: true,
    appQuota: []
    }
  },
  mixins: [validationMixin],
  validations: {
  },
  created () {
     this.getvirtualpoolDetails();
     this.getAppQuota();
  },
  methods: {
      enableAction (actionType) {
  },
    getvirtualpoolDetails () {
      const infoProps = {
        'workflowSync': 'getSIOVP',
        'parameters': {
        'vpId': this.$route.params.vpID
            }
        }
          
      this.$http
        .post('https://vm-86ae-9639.nam.nsroot.net:6400/citistorage/sit/scaleio/management/execute?', infoProps, apiheaders)
        .then((response) => {
          this.virtualpoolDetails = response.body;
        })
        .catch((response) => {
          console.log(response)
        })
    },
    getAppQuota () {
      var vpIds = [this.$route.params.vpID]
      var action = 'getSIOQuota' || 'getSIOUsage' 
      const infoProps = {
        'workflowSync': action,
        'parameters': {
          'arrVps': JSON.stringify(vpIds)
        }
          }
          
      this.$http
        .post('https://vm-86ae-9639.nam.nsroot.net:6400/citistorage/sit/scaleio/management/execute?', infoProps, apiheaders)
        .then((response) => {
          this.appQuota = response.body;
        })
        .catch((response) => {
          console.log(response)
        })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.mt-10{
  margin-top:10px;
}
</style>
