<template>
  <div><b-row>
  <b-col class="mt-10">
    <b-card-group deck>
        <b-card title="Cluster">
            <p class="card-text">
                All Resources (also called catalog items) available in the OMS are ordered on behalf of a Citi Application (app)
            </p>
            <div slot="footer">
                <b-button to="/scaleIO/Cluster"
                      variant="primary">Details</b-button>
            </div>
        </b-card>
        <b-card title="Pools">
            <p class="card-text">
                Some orders will require user to provide server names
            </p>
            <div slot="footer">
                <b-button to="/scaleIO/Pools"
                      variant="primary">Order</b-button>
            </div>
        </b-card>
        <b-card title="Virtual Pool">
            <p class="card-text">
                Virtual Pool is a configuration element in the ScaleIO Self-Service API that restricts provisioning access to certain clusters and pools
            </p>
            <div slot="footer">
                <b-button to="/scaleIO/VirtualPool"
                      variant="primary">Order</b-button>
            </div>
        </b-card>
        <b-card title="Subscribers">
            <p class="card-text">
                Some orders will require user to provide server names.
            </p>
            <div slot="footer">
                <b-button to="/scaleIO/Subscribers"
                      variant="primary">Order</b-button>
            </div>
        </b-card>

    </b-card-group>
    </b-col>
    </b-row>
 </div>
</template>

<script>
export default {
  name: 'ScaleIO',
  data () {
    return {
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.mt-10{
  margin-top:10px;
}
</style>
