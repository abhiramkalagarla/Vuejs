<template>
  <b-row>
  <b-col class="mt-10" md="12" sm="12" xs="12">
   <h2>Place Order</h2>
   </b-col>
   <b-col md="8" sm="12" xs="12">
    <b-form  @submit="onSubmit">
    <b-form-group id="exampleInput1"
                    label="Resource Name:"
                    horizontal
                    :label-cols="3"
                    breakpoint="md"
                   
                    label-for="exampleInput1">
        <b-form-input id="resourceName"
                      label="Resource Name"
                      label-for="exampleInput2"
                      v-model="form.resourceName"
                      @input="$v.form.resourceName.$touch()"
                      :state="!$v.form.resourceName.$invalid"
                      placeholder="Enter Resource Name">
        </b-form-input>
      </b-form-group>
      <b-form-group id="exampleInput1"
                    label="Master VM"
                    horizontal
                    :label-cols="3"
                    breakpoint="md"
                    label-for="exampleInput1">
        <b-form-input id="masterVM"
                      label="Master VM"
                      label-for="masterVM"
                      v-model="form.masterVM"
                      @input="$v.form.masterVM.$touch()"
                      :state="!$v.form.masterVM.$invalid"
                      placeholder="Select Master VM">
        </b-form-input>
      </b-form-group>
      <b-form-group id="exampleInput1"
                    label="Source Directory"
                    horizontal
                    :label-cols="3"
                    breakpoint="md"
                    label-for="exampleInput1">
        <b-form-input id="sourceDirectory"
                      label="Source Directory"
                      label-for="exampleInput2"
                      v-model="form.sourceDirectory"
                      @input="$v.form.sourceDirectory.$touch()"
                      :state="!$v.form.sourceDirectory.$invalid"
                      placeholder="Enter Source Directory">
        </b-form-input>
      </b-form-group>
      <b-form-group id="exampleInput1"
                    label="Replica VM:"
                    horizontal
                    :label-cols="3"
                    breakpoint="md"
                    label-for="exampleInput1">
        <b-form-input id="replicaVM"
                      label="Replica VM"
                      label-for="exampleInput2"
                      v-model="form.replicaVM"
                      @input="$v.form.replicaVM.$touch()"
                      :state="!$v.form.replicaVM.$invalid"
                      placeholder="Enter Replica VM">
        </b-form-input>
      </b-form-group>
      <b-form-group id="exampleInput1"
                    label="Destination Directory:"
                    horizontal
                    :label-cols="3"
                    breakpoint="md"
                    label-for="exampleInput1">
        <b-form-input id="destinationDirectory"
                      label="Destination Directory"
                      label-for="exampleInput2"
                      v-model="form.destinationDirectory"
                      @input="$v.form.destinationDirectory.$touch()"
                      :state="!$v.form.destinationDirectory.$invalid"
                      placeholder="Enter Destination Directory">
        </b-form-input>
      </b-form-group>
      <b-form-group id="exampleInput1"
                    label="Order Details:"
                    horizontal
                    :label-cols="3"
                    breakpoint="md"
                    
                    label-for="exampleInput1">
        <b-form-input id="orderDetails"
                      label="Order Details"
                      label-for="exampleInput2"
                      v-model="form.orderDetails"
                      @input="$v.form.orderDetails.$touch()"
                      :state="!$v.form.orderDetails.$invalid"
                      placeholder="Enter Order Details">
        </b-form-input>
      </b-form-group>
      <b-form-group id="formcsiID"
                    label="CSIID:"
                    horizontal
                    :label-cols="3"
                    breakpoint="md"
                    
                    label-for="formcsiID">
          <b-form-input id="csiID"
                      label="csiID"
                      label-for="exampleInput2"
                      v-model="form.csiID"
                      @input="$v.form.csiID.$touch()"
                      :state="!$v.form.csiID.$invalid"
                      placeholder="Enter CSIID">
           </b-form-input>
      </b-form-group>            
        
      <b-form-group id="authorizedAdmins"
                    label="Authorized Admins:"
                    horizontal
                    :label-cols="3"
                    breakpoint="md"
                   
                    label-for="formauthorizedAdmins">
          <b-form-input id="authorizedAdmins"
                      label="authorizedAdmins"
                      label-for="exampleInput2"
                      v-model="form.authorizedAdmins"
                      @input="$v.form.authorizedAdmins.$touch()"
                      :state="!$v.form.authorizedAdmins.$invalid"
                      placeholder="Enter Authorized Admins">
           </b-form-input>
      </b-form-group>
      <b-form-group id="formbillingID"
                    label="BillingID:"
                    horizontal
                    :label-cols="3"
                    breakpoint="md"
                    
                    label-for="formbillingID">
          <b-form-input id="billingID"
                      label="billingID"
                      label-for="exampleInput2"
                      v-model="form.billingID"
                      @input="$v.form.billingID.$touch()"
                      :state="!$v.form.billingID.$invalid"
                      placeholder="Enter Billing ID">
           </b-form-input>
      </b-form-group>
      <b-col  offset-md="3">
      <b-button type="submit" :disabled="$v.form.$invalid" variant="primary">Submit</b-button>
      <b-button type="reset" variant="danger">Reset</b-button>
      </b-col>
      {{orderInfo}}
    </b-form>
</b-col>

  </b-row>
</template>

<script>
import { validationMixin } from 'vuelidate'
import { required } from 'vuelidate/lib/validators'
export default {
  name: 'PlaceOrder',
  data () {
    return {
      auth: this.$store.state.auth,
      form: {},
      masterVM: '',
      sourceDirectory: '',
      replicaVM: '',
      destinationDirectory: '',
      orderInfo: '',
      resourceName: '',
      csiID: '',
      orderDetails: '',
      billingID: '',
      authorizedAdmins: ''
    }
  },
  mixins: [validationMixin],
  validations: {
    form: {
      resourceName: {
        required
      },
      csiID: {
        required
      },
      masterVM: {
        required
      },
      sourceDirectory: {
        required
      },
      replicaVM: {
        required
      },
      destinationDirectory: {
        required
      },
      orderDetails: {
        required
      },
      authorizedAdmins: {
        required
      },
      billingID: {
        required
      }
    }
  },
  methods: {
    onSubmit (e) {
      e.preventDefault()
      this.placeOrder()
    },
    placeOrder () {
 const apiheaders = {
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json'
  }
}
      const infoProps = {
        'action': 'com.citi.cloud.oms/acceptOrder',
        'parameters': {
          'resourceName': this.form.resourceName,
           'orderDetails': this.form.orderDetails,
           'csiID': this.form.csiID,
           'authorizedAdmins': this.form.authorizedAdmins,
           'billingID': this.form.billingID
          }
          }
          
      this.$http
        .post('https://vm-86ae-9639.nam.nsroot.net:6400/citistorage/sit/oms/execute', infoProps, apiheaders)
        .then((response) => {
          this.orderInfo = response;
        })
        .catch((response) => {
          console.log(response)
          // this.error = utils.getError(response)
        })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.mt-10{
  margin-top:10px;
}
</style>
