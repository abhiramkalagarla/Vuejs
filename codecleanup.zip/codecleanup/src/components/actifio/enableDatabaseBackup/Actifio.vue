<template>
  <div class="mt-2">
  <b-form @submit.stop.prevent="onSubmitform">
  <b-row>
  <b-col md="8">
  <h2 class="text-center">Enable Database Backup</h2><br>
    <b-form-group id="Group1"
                  label="CSI Application ID"
                  class="required"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="appID">
                  <b-input-group>
    <b-form-input id="appID"
                    type="text"
                    v-model="actifio.CSIID"
                    aria-describedby="appID"
                    placeholder="Enter CSI App ID" />
                    <b-input-group-append>
                    <b-btn variant="primary" @click="getAppInfo()">Lookup</b-btn>
                    </b-input-group-append>
                    </b-input-group>
      <span class="invalid-feedback d-block" v-if="isValidCSIID">The Entered CSIID is invalid. Please try again...</span>
    </b-form-group>

    <b-form-group id="OfflinePools"
                  class="required"
                  label="Billing ID"
                  description="Select BillingID"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="billingID">
    <b-form-select id="billingID"
                 :options="billingId"
                  v-model="actifio.billingID"
                  aria-describedby="billingID"
                  placeholder="Select Billing ID" />
    </b-form-group>

    <b-form-group id="OfflinePools"
                  class="required"
                  label="DBA Group dl"
                  description="Members of this distribution list will be allowed to manage the protection once it is provisioned"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="groupdl">
      <b-form-select id="datacenter"
                    :options="groupDl"
                    v-model="actifio.authorizedADGroup"
                    aria-describedby="groupdl"
                    placeholder="Enter DBA Group dl"/>
    </b-form-group>

    <b-form-group id="purpose"
                  class="required"
                  label="Backup Purpose"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="purpose">
      <b-form-select id="purpose"
                    :options="purpose"
                    v-model="actifio.purpose"
                    aria-describedby="purpose"
                    placeholder="Select the Backup Purpose"/>
    </b-form-group>

    <b-form-group id="OfflinePools"
                  class="required"
                  label="Database Type"
                  horizontal
                  :label-cols="4"
                  breakpoint="md"
                  label-for="database">
      <b-form-select id="database"
                    :options="database"
                    v-model="actifio.database"
                    aria-describedby="database"
                    placeholder="Select the Database Type"/>
    </b-form-group>
  </b-col>
  </b-row>
<mssqlTable  v-if="actifio.database==='MSSQL'" @update="onStep1Update"></mssqlTable>
<oracle v-if="actifio.database==='Oracle'" @update="onStep1Update"></oracle>
    <b-row>
    <b-col  md="8" offset-md="4" class="mt-1">
      <button  class="btn btn-primary" :disabled="$v.actifio.$invalid || disableform || issubmitted ">Submit the DPS Order</button> 
    </b-col>
    </b-row>
      </b-form>
  </div>
</template>

<script>
import { validationMixin } from 'vuelidate'
import { required } from 'vuelidate/lib/validators'
import mssqlTable from './mssqlTable.vue'
import oracle from './oracle.vue'
export default {
  name: 'Dashboard',
  components: { mssqlTable, oracle },
  data () {
    return {
         billingId: [],
         groupDl: [],
         isValidCSIID: false, 
         showMsSqlTable: false,
         disableform: true,
         issubmitted: false,
         showOracleTable: false,
         purpose: ['Choose...', 'Appendix J', 'Non - ORAAS', 'VM Backup'],
         database: [{ value: null, text: 'Please select Database' }, 'MSSQL', 'Oracle'],
         actifio: {},
         actinfolookup: {},
         template: 'default'
    }
  },
  mixins: [validationMixin],
  validations: {
    actifio: {
      CSIID: {
        required
      },
      billingID: {
        required
      },
      authorizedADGroup: {
        required
      },
      purpose: {
        required
      },
      database: {
        required
      }
    }
  },
  created () {
    // this.getAppInfo();
    this.getusergroups()
  },
  watch: {
  'actifio.CSIID': function (val, oldVal) {
  this.billingId = []
    }
  },
  methods: {
    onStep1Update (newData) {
    this.issubmitted = false
    this.disableform = newData.isValid
    this.actifio.serverDetails = newData.serverDetails
      },
    onSubmitform (e) {
      e.preventDefault()
      this.postSubmitOrder()
      },
    onSubmit (e) {
      e.preventDefault()
      this.getappInfo()
    },
    getAppInfo () {
      const apiheaders = {
        headers: {
          'Content-Type': 'application/json'      
        }
      }          
      this.$http
        .get('/api/apps?CSIID=' + this.actifio.CSIID, {}, apiheaders)
        .then((response) => {
         this.billingId = response.body.billingIDs
         if (response.body.billingIDs.length == 1) {
           this.actifio.billingID = response.body.billingIDs[0]
         }
         this.isValidCSIID = false;
         alert('Billing ID found, Please select below')
        })
        .catch((response) => {
          this.isValidCSIID = true;
          // this.$toasted.show('The Entered CSIID is invalid. Please try again...', {type: 'error', duration: 5000})
          console.log(response)
        })
    },
    getemailDL (data) {
      var c = []
      for (var i = 0; i < data.length; i++) {
        if (data[i].split(',')[1].split('=')[1] === 'Dist_Grps' || data[i].split(',')[1].split('=')[1] === 'Dist_Groups') {
        c.push({value: data[i], text: data[i].split(',')[0].split('=')[1]})
            }
      }
      this.groupDl = c;
    },
    getusergroups () {
      const apiheaders = {
        headers: {
          'Content-Type': 'application/json'      
  }
}          
      this.$http
        .get('/api/user/groups', apiheaders)
        .then((response) => {
          this.getemailDL(response.body)
        })
        .catch((response) => {
          console.log(response)
        })
    },
    postSubmitOrder () {
      this.issubmitted = true
      const apiheaders = {
        headers: {
          'Content-Type': 'application/json'      
  }
}          
      this.$http
        .post('/api/dps/create', this.actifio, apiheaders)
        .then((response) => {
          this.actifio.database = 'Please select Database'
         alert('Order Submitted Successfully!')
        })
        .catch((response) => {
          this.issubmitted = false
          console.log(response)
          alert('Order not Submitted Correctly!')
        })
  }
}
}
</script>
