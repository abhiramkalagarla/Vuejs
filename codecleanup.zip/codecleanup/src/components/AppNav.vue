<template>
<b-navbar id="citiBrandingNav" toggleable="md" type="dark" variant="info">

  <b-navbar-toggle target="nav_collapse"></b-navbar-toggle>

  <b-navbar-brand to='/'><div class="brandingLogo " alt="Citi Bank Logo"><span class="sr-only">Citi Bank Logo</span></div></b-navbar-brand>

<span class="navbar-text mt10 fg-white font-xl">
     Citi Storage
    </span>
  <b-collapse is-nav id="nav_collapse">

    <template v-if="auth.isLoggedIn">
    <b-navbar-nav class="ml-auto"> 
    <b-nav-item :to="{name:'applicationInfo'}" >Application Info</b-nav-item>
    <b-nav-item :to="{name:'ServerInfo'}">Server Info</b-nav-item>
    <b-nav-item :to="{name:'orderhistory'}">Order History</b-nav-item> 
    <b-nav-item-dropdown right>
        <template slot="button-content">
         Welcome <em>{{user}}</em>
        </template>
        <b-dropdown-item href="#"  @click="logout()">Signout</b-dropdown-item>
      </b-nav-item-dropdown>
  
</b-navbar-nav>    
</template>
  </b-collapse>
</b-navbar>
</template>

<script>
import Auth from '@/auth'
export default {
  data () {
    return {
       auth: this.$store.state.auth,
       user: this.$store.state.user.name
    }
  },
  methods: {
    logout () {
      Auth.logout()
    }
  }
}
</script>

<style lang="scss" scoped>
#citiBrandingNav {
    width: 100%;
    height: 86px;
    padding: 0 20px;
    background: -webkit-linear-gradient(top, #00bdf2, #00b3f0 18%, #0066b3 77%, #004985);
    background: linear-gradient(180deg, #00bdf2, #00b3f0 18%, #0066b3 77%, #004985)
}
#citiBrandingNav {
    -webkit-transition: all .2s cubic-bezier(.55, .085, .68, .53);
    transition: all .2s cubic-bezier(.55, .085, .68, .53)
}
.brandingLogo {
    z-index: 460;
    float: left;
    width: 69px;
    height: 40px;
   margin: 1px 0 0 20px!important;

    background: url(../assets/Citi-Enterprise-White.png) no-repeat 0;
    background-size: 100% auto
}
</style>
