import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const router = new Router({
  mode: 'history',
  routes: [
    // Each of these routes are loaded asynchronously, when a user first navigates to each corresponding endpoint.
    // The route will load once into memory, the first time it's called, and no more on future calls.
    // This behavior can be observed on the network tab of your browser dev tools.
    {
      path: '/login',
      name: 'login',
      component: function (resolve) {
        require(['@/components/login/Login.vue'], resolve)
      }
    },
    {
      path: '/',
      redirect: 'home'
    },
    {
      path: '/home',
      name: 'Home',
      component: function (resolve) {
        require(['@/components/dashboard/Dashboard.vue'], resolve)
      },
      meta: {
        breadcrumb: 'Home'
    },
      beforeEnter: guardRoute
    },
    {
      path: '/serverInfo',
      name: 'ServerInfo',
      component: function (resolve) {
        require(['@/components/serverInfo/ServerInfo.vue'], resolve)
      },
      meta: {
       breadcrumb: 'Server Info'
    }
      // beforeEnter: guardRoute
    },
    {
      path: '/applicationInfo',
      name: 'applicationInfo',
      meta: {
        breadcrumb: 'Application Info'
    },
      component: function (resolve) {
        require(['@/components/applicationInfo/ApplicationInfo.vue'], resolve)
      }
    // beforeEnter: guardRoute
    },
    {
      path: '/placeorder',
      name: 'placeorder',
      meta: {
        breadcrumb: 'Place Order'
    },
      component: function (resolve) {
        require(['@/components/placeOrder/PlaceOrder.vue'], resolve)
      }
    //  beforeEnter: guardRoute
    },
    {
      path: '/orderhistory',
      name: 'orderhistory',
      meta: {
        breadcrumb: 'Order History'
    },
      component: function (resolve) {
        require(['@/components/orderHistory/OrderHistory.vue'], resolve)
      }
   //  beforeEnter: guardRoute
    },
    {
      path: '/scaleIO',
      name: 'scaleIO',
      meta: {
        breadcrumb: 'Scale IO'
    },
      component: function (resolve) {
        require(['@/components/scaleIO/ScaleIO.vue'], resolve)
      }
    //  beforeEnter: guardRoute
    },
    {
      path: '/scaleIO/Cluster',
      name: 'Cluster',
      meta: {
        breadcrumb: 'Cluster'
    },
      component: function (resolve) {
        require(['@/components/scaleIO/Cluster/Cluster.vue'], resolve)
      }
  // beforeEnter: guardRoute
    },
    {
      path: '/scaleIO/Pools',
      name: 'Pools',
      meta: {
        breadcrumb: 'Pools'
    },
      component: function (resolve) {
        require(['@/components/scaleIO/Pools/Pools.vue'], resolve)
      }
  // beforeEnter: guardRoute
    },
    {
      path: '/scaleIO/Pools/:citipoolname',
      name: 'Citipool',
      meta: {
        breadcrumb: 'CitiPools'
    },
      component: function (resolve) {
        require(['@/components/scaleIO/Pools/indPool.vue'], resolve)
      }
   // beforeEnter: guardRoute
    },
    {
      path: '/scaleIO/VirtualPool',
      name: 'VirtualPool',
      meta: {
        breadcrumb: 'VirtualPool'
    },
      component: function (resolve) {
        require(['@/components/scaleIO/Virtual Pool/VirtualPool.vue'], resolve)
      }
  // beforeEnter: guardRoute
    },
    {
      path: '/scaleIO/VirtualPool/:vpID',
      name: 'IndvirtualPool',
      meta: {
        breadcrumb: 'VirtualPool'
    },
      component: function (resolve) {
        require(['@/components/scaleIO/Virtual Pool/indVirtualPool.vue'], resolve)
      }
   // beforeEnter: guardRoute
    },
    {
      path: '/vmReplication',
      name: 'vmReplication',
      meta: {
        breadcrumb: 'VM Replication'
    },
      component: function (resolve) {
        require(['@/components/vmReplication/VMReplication.vue'], resolve)
      }
  // beforeEnter: guardRoute
    },
    {
      path: '/actifio',
      name: 'actifio',
      meta: {
        breadcrumb: 'actifio'
    },
      component: function (resolve) {
        require(['@/components/actifio/actifioCard.vue'], resolve)
      }
    //  beforeEnter: guardRoute
    },
    {
      path: '/actifio/manageDatabaseBackup',
      name: 'manageDatabaseBackup',
      meta: {
        breadcrumb: 'Manage Database Backup'
    },
      component: function (resolve) {
        require(['@/components/actifio/manageDatabaseBackup/manageDatabaseBackup.vue'], resolve)
      }
   //  beforeEnter: guardRoute
    },
    {
      path: '/actifio/databaseBackupDashboard',
      name: 'databaseBackupDashboard',
      meta: {
        breadcrumb: 'Database Backup Dashboard'
    },
      component: function (resolve) {
        require(['@/components/actifio/databaseBackupDashboard/databaseBackupDashboard.vue'], resolve)
      }
    // beforeEnter: guardRoute
    },
    {
      path: '/actifio/enableDatabaseBackup',
      name: 'enableDatabaseBackup',
      meta: {
        breadcrumb: 'Enable Database Backup'
    },
      component: function (resolve) {
        require(['@/components/actifio/enableDatabaseBackup/Actifio.vue'], resolve)
      }
    // beforeEnter: guardRoute
    },
    {
      path: '/actifio/enableDatabaseBackup',
      name: 'enableDatabaseBackup',
      meta: {
        breadcrumb: 'Enable Database Backup'
    },
      component: function (resolve) {
        require(['@/components/actifio/enableDatabaseBackup/mssqlTable.vue'], resolve)
      }
   //  beforeEnter: guardRoute
    },
    {
      path: '/actifio/enableDatabaseBackup',
      name: 'enableDatabaseBackup',
      meta: {
        breadcrumb: 'Enable Database Backup'
    },
      component: function (resolve) {
        require(['@/components/actifio/enableDatabaseBackup/oracle.vue'], resolve)
      }
   //  beforeEnter: guardRoute
    },
    {
      path: '/objectStorage',
      name: 'objectStorage',
      meta: {
        breadcrumb: 'ObjectStorage'
    },
      component: function (resolve) {
        require(['@/components/objectStorage/ObjectStorage.vue'], resolve)
      }
   // beforeEnter: guardRoute
    },
    {
      path: '*',
      name: 'notfound',
      meta: {
        breadcrumb: 'Not Found'
    },
      component: function (resolve) {
        require(['@/components/notFound/NotFound.vue'], resolve)
      }
    }
  ]
})

function guardRoute (to, from, next) {
  // work-around to get to the Vuex store (as of Vue 2.0)
  const auth = router.app.$options.store.state.auth

  if (!auth.isLoggedIn) {
    next({
      path: '/login',
      query: { redirect: to.fullPath }
    })
  } else {
    next()
  }
}

export default router
